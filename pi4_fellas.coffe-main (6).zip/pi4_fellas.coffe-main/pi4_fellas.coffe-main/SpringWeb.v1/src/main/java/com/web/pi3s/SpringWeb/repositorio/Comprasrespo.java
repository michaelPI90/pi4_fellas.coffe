package com.web.pi3s.SpringWeb.repositorio;


import org.springframework.data.repository.CrudRepository;

import com.web.pi3s.SpringWeb.models.Compra;

public interface Comprasrespo extends  CrudRepository<Compra, Integer>  {


}
