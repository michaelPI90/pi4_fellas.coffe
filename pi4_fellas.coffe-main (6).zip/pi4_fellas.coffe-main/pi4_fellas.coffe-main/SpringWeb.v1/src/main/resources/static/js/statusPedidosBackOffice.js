function editarPedido() {

    var componenteCombobox = document.getElementById("combobox-status");

    if (componenteCombobox.disabled) {
        componenteCombobox.disabled = false;
    } else {
        componenteCombobox.disabled = true;
    }
}

function editarPedido2() {

    var componenteCombobox = document.getElementById("combobox-status-2");

    if (componenteCombobox.disabled) {
        componenteCombobox.disabled = false;
    } else {
        componenteCombobox.disabled = true;
    }


}

function editarPedido3() {

    var componenteCombobox = document.getElementById("combobox-status-3");

    if (componenteCombobox.disabled) {
        componenteCombobox.disabled = false;
    } else {
        componenteCombobox.disabled = true;
    }
}

function editarPedido4() {

    var componenteCombobox = document.getElementById("combobox-status-4");

    if (componenteCombobox.disabled) {
        componenteCombobox.disabled = false;
    } else {
        componenteCombobox.disabled = true;
    }
}

function editarPedido5() {

    var componenteCombobox = document.getElementById("combobox-status-5");

    if (componenteCombobox.disabled) {
        componenteCombobox.disabled = false;
    } else {
        componenteCombobox.disabled = true;
    }
}
