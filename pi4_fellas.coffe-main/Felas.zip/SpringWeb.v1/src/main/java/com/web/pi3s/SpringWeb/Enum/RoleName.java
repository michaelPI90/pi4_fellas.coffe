package com.web.pi3s.SpringWeb.Enum;

public enum RoleName {
    ROLE_ADMIN,
    ROLE_CLIENTE,
    ROLE_ESTOQUISTA;



}
